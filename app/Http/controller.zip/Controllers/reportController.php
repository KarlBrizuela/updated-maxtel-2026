<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use DB;
use Yajra\DataTables\DataTables;

use App\Exports\exportExcel;
use Maatwebsite\Excel\Facades\Excel;
use Dompdf\Dompdf;

class reportController extends Controller
{
    public function report_management(){

        return view("report.index");

    }

    public function report_pay_list(Request $request){
           // update payroll
           if(Auth::user()->access[$request->page]["user_type"] == "employee"){
            $emp_id = Auth::user()->company["linked_employee"]["id"];
            $payroll_data = DB::connection("intra_payroll")->table("tbl_payroll")
            ->where(function($query) {
                $query->where("payroll_status", "COMPUTED")
                      ->orWhere("payroll_status", "FINALIZE")
                      ->orWhere("payroll_status", "CLOSE");
            })
            ->where('employee', 'LIKE', '%|' . $emp_id . '|%')
            ->orderBy("date_updated", "DESC")
            ->get();

        }else{
            $payroll_data = DB::connection("intra_payroll")->table("tbl_payroll")
            ->where("payroll_status", "COMPUTED")
            ->orWhere("payroll_status", "FINALIZE")
            ->orWhere("payroll_status", "CLOSE")
            ->orderBy("date_updated", "DESC")
            ->get();
        }
        $data = collect($payroll_data);


        $page_permission = Auth::user()->access[$request->page]["access"];
        $process_type_array = array(
            "RP" => "Regular",
            "13" => "13th Month",
            "BP" => "Bonus",
            "SP" => "Special",
        );


        return Datatables::of($data)
            ->addColumn('name', function($row){
                return "(".$row->code.") ".$row->name;
            })
            ->addColumn('info', function($row) use ($process_type_array){
                $info = $row->target_month." ".$row->target_year."<br>";
                
                $info.= $process_type_array[$row->process_type]." (".$row->type.")";
                
                    return $info;
            })
            ->addColumn('status', function($row){
                if($row->payroll_status == "OPEN"){
                    $btn = "<label > Open </label>";
                }elseif($row->payroll_status == "ADDED"){
                    $btn = "<label > ADDED </label>";
                }elseif($row->payroll_status == "PROCESS"){
                    $btn = "<label > TIMECARD <br> PROCESSED </label>";
                }elseif($row->payroll_status == "COMPUTED"){
                    $btn = "<label > PAYROLL <br> COMPUTED </label>";
                }elseif($row->payroll_status == "FINALIZE"){
                    $btn = "<label > FOR APPROVAL </label>";
                }
                else{
                    $btn = "<label > PAYROLL COMPLETED </label>";
                }
                return $btn;
            })
        ->addColumn('action', function($row) use ($page_permission, $request ){
            $btn = "";
            if(preg_match("/U/i", $page_permission)){
                if(Auth::user()->access[$request->page]["user_type"] != "employee"){
                    $btn .= "<button  onclick='export_payroll($row->id)' class='export_payroll btn btn-success btn-sm w-100 mb-1'>Payroll Report</button> <br>";
                    $btn .= "<button class='btn btn-info btn-sm w-100' onclick='download_payslip($row->id)'>Payslip</button>";
                    
                }else{
                    //employee
                    $btn .= "<button class='btn btn-info btn-sm w-100' onclick='download_payslip($row->id)'>Payslip</button>";
                }
            }
          
            return $btn;
        })
        ->rawColumns(['action','status','info'])
        ->make(true);

    }
    private function search_to_array($array, $key, $value) {
        $results = array();
    
        if (is_array($array)) {
            if (isset($array[$key]) && $array[$key] == $value) {
                $results[] = $array;
            }
    
            foreach ($array as $subarray) {
                $results = array_merge($results, $this->search_to_array($subarray, $key, $value));
            }
        }
    
        return $results;
    }

    public function payroll_payslip(Request $request){
        $dompdf = new Dompdf();
        $pay_id = $request->pay_id;
        $payroll_data = DB::connection("intra_payroll")->table("tbl_payroll")
            ->where('id', $pay_id)
            ->first();

        $income_list = json_decode(json_encode(DB::connection("intra_payroll")->table("tbl_payroll_income")->where("payroll_id", $pay_id)->get()), true);
            $lib_income = json_decode(json_encode(DB::connection("intra_payroll")->table("lib_income")->get()), true);
        $deduction_list = json_decode(json_encode(DB::connection("intra_payroll")->table("tbl_payroll_deduction")->where("payroll_id", $pay_id)->get()), true);
            $lib_loans = json_decode(json_encode(DB::connection("intra_payroll")->table("lib_loans")->get()), true);
        $tbl_employee = json_decode(json_encode(DB::connection("intra_payroll")->table("tbl_employee")->get()), true);
        
        $income_header = array(
            "BP" => "Basic Pay",
            "RH" => "Regular Holiday",
            "ROT" => "Regular Overtime",
            "SOT" => "Special Overtime",
            "13TH" => "13th Month Pay",
            "SH" => "Special Holiday",
            "ND" => "Night Differential",
        );

        $deduction_header = array(
            "SSS" => "SSS",
            "HDMF" => "PAGIBIG I (HDMF)",
            "PH" => "PhilHealth",
            "TAX" => "WIHHOLDING TAX",
            "LATE" => "LATE",
            "ABSENT" => "ABSENT",
        );

        if(Auth::user()->access["report_management"]["user_type"] != "employee"){
            $reg_emp_id = "all";
        }else{
            $reg_emp_id = Auth::user()->company["linked_employee"]["id"];
        }

        $payslip_data = array();
        

        if($payroll_data != null){
            $emp_data = explode(";",$payroll_data->employee);
            foreach($emp_data as $emp){
                $payslip_income = array();
                $payslip_deduction = array();

                

                $emp_id = str_replace("|","", $emp);
                
                if($reg_emp_id != "all"){
                    if($reg_emp_id != $emp_id){continue;}
                }
                


                $employee = $this->search_to_array($tbl_employee, "id",$emp_id);
                $departmentData = DB::connection("intra_payroll")
                    ->table("tbl_department")
                    ->select("department")
                    ->where("id", $employee[0]["department"])
                    ->first();
                $departmentName = $departmentData ? $departmentData->department : null;
                $branchtData = DB::connection("intra_payroll")
                    ->table("tbl_branch")
                    ->select("branch")
                    ->where("id", $employee[0]["branch_id"])
                    ->first();
                $branchName = $branchtData ? $branchtData->branch : null;
                if(count($employee)==1){
                    $emp_data = array(
                        "id" => $employee[0]["id"],
                        "department" => $departmentName,
                        "branch" => $branchName,
                        "employee_code" =>  strtoupper($employee[0]["emp_code"]),
                        "last_name" =>  strtoupper($employee[0]["last_name"]),
                        "first_name" =>  strtoupper($employee[0]["first_name"]),
                        "middle_name" =>  substr(strtoupper($employee[0]["middle_name"]),0,1) ,
                        "ext_name" =>  strtoupper($employee[0]["ext_name"])
                    );

                    // $total_incomes = 0;
                    $income =  $this->search_to_array($income_list, "emp_id", $emp_id);
                    foreach($income as $inc){
                        $income_name =  $this->search_to_array($lib_income, "id", str_replace("R_","", $inc["type"]));
                        if(count($income_name) == 1){
                            $inc_name = $income_name[0]["name"];
                        }else{
                            if(isset($income_header[$inc["type"]])){
                                $inc_name = $income_header[$inc["type"]];
                            }else{
                                $inc_name = "N/A";
                            }
                            
                        }
                        // $total_incomes += floatval($inc["amount"]);
                       $inc_data = array(
                            "emp_id" => $emp_id,
                            "income_name" => $inc_name,
                            "amount" => $inc["amount"]
                       );
                    
                       array_push($payslip_income, $inc_data);
                    }
                    

                    // $total_deduction = 0;
                    $deduction =  $this->search_to_array($deduction_list, "emp_id", $emp_id);
                    foreach($deduction as $ded){
                        $deduction_name =  $this->search_to_array($lib_loans, "id", str_replace("R_","", $ded["type"]));
                        if(count($deduction_name) == 1){
                            $ded_name = $deduction_name[0]["name"];
                        }else{
                            if(isset($deduction_header[$ded["type"]])){
                                $ded_name = $deduction_header[$ded["type"]];
                            }else{
                                $ded_name = "N/A";
                            }
                            
                        }
                        // $total_deduction += floatval($ded["amount"]);
                       $ded_data = array(
                            "emp_id" => $emp_id,
                            "deduction_name" => $ded_name,
                            "amount" => $ded["amount"]
                       );
                      
                       array_push($payslip_deduction, $ded_data);
                    }




                }else{
                    continue;
                }


                $emp_data["incomes"] = $payslip_income;
                $emp_data["deductions"] = $payslip_deduction;
          

                array_push($payslip_data, $emp_data);
            }


            
        }



        $company_info = array(
            "company_name" => Auth::user()->company["company_name"],
            "logo_main" => asset(Auth::user()->company["logo_main"]),
            "address" => Auth::user()->company["address"],
            
        );
        
        $cover_from = $payroll_data->cover_from; //2025-01-01
        $cover_to = $payroll_data->cover_to; //2025-01-19
        $period = date('F d', strtotime($cover_from)) . '-' . date('d, Y', strtotime($cover_to));
      

        $dompdf->loadHtml(view('report.payslip', compact('company_info','payslip_data','period')));
        $dompdf->setPaper('A4');
        // $dompdf->setOptions(['isRemoteEnabled' => true]);
        $dompdf->render();
        
        return $dompdf->stream('document.pdf');

    }


    
    public function exportRegIncome(Request $request){

        if(Auth::user()->access["report_management"]["user_type"] != "employee"){
            $income = DB::connection("intra_payroll")->table("tbl_income_file")
                ->whereBetween("date_created", [$request->from, $request->to])
                ->orderBy("emp_id")
                ->get();

        }else{
             $income = DB::connection("intra_payroll")->table("tbl_income_file")
                ->whereBetween("date_created", [$request->from, $request->to])
                ->where("emp_id", Auth::user()->company["linked_employee"]["id"])
                ->orderBy("emp_id")
                ->get();
        }

        
            $tbl_employee = DB::connection("intra_payroll")->table("tbl_employee")->get();
            $tbl_employee = json_decode(json_encode($tbl_employee), true);
    
            $lib_income = DB::connection("intra_payroll")->table("lib_income")->get();
            $lib_income = json_decode(json_encode($lib_income), true);

            $header = array();
            
            array_push($header, "Employee Code");
            array_push($header, "Last Name");
            array_push($header, "First Name");
            array_push($header, "Middle Name");
            array_push($header, "Extension Name");
            array_push($header, "Income");
            array_push($header, "Income Type");
            
            array_push($header, "Amount / 1");
            array_push($header, "Amount / 2");
            array_push($header, "Amount / 3");
            array_push($header, "Amount / 4");
            array_push($header, "Amount / 5");
            array_push($header, "Date Created");
            
            
            
            $excel_data = array();
            foreach($income as $inc){
                $excel = array();
                $emp_data = $this->search_to_array($tbl_employee, "id",$inc->emp_id);
                if(count($emp_data)==1){
                    $excel["emp_code"] = $emp_data[0]["emp_code"];
                    $excel["last_name"] = $emp_data[0]["last_name"];
                    $excel["first_name"] = $emp_data[0]["first_name"];
                    $excel["middle_name"] = $emp_data[0]["middle_name"];
                    $excel["ext_name"] = $emp_data[0]["ext_name"];
                    
                }else{
                    $excel["emp_code"] = "N/A";
                    $excel["last_name"] = "N/A";
                    $excel["first_name"] = "N/A";
                    $excel["middle_name"] = "N/A";
                    $excel["ext_name"] = "N/A";

                }

                $lib_data = $this->search_to_array($lib_income, "id",$inc->income_id);
                if(count($lib_data)==1){
                    $excel["income"] = $lib_data[0]["name"];
                }else{
                    // dd($lib_income);
                    // dd($inc->income_id);
                    $excel["income"] = "N/A";
                }

                $excel["inc_type"] = $inc->income_type;
                $excel["amount_1"] = $inc->amount;
                $excel["amount_2"] = $inc->amount_2;
                $excel["amount_3"] = $inc->amount_3;
                $excel["amount_4"] = $inc->amount_4;
                $excel["amount_5"] = $inc->amount_5;
                $excel["date_created"] = $inc->date_created;

               
                
                array_push($excel_data, $excel);
            }
            
            $excel_data = collect($excel_data);
            return Excel::download(new exportExcel($excel_data,$header), "Regular Income".$request->from."_".$request->to.".xlsx");


    }



    
    public function exporEmpList(Request $request){

        $lib_position = json_decode(json_encode(DB::connection("intra_payroll")->table("lib_position")->get()),true);
        $tbl_branch = json_decode(json_encode(DB::connection("intra_payroll")->table("tbl_branch")->get()),true);
        $tbl_department = json_decode(json_encode(DB::connection("intra_payroll")->table("tbl_department")->get()),true);
        $lib_designation = json_decode(json_encode(DB::connection("intra_payroll")->table("lib_designation")->get()),true);
        

        if(Auth::user()->access["report_management"]["user_type"] != "employee"){
            $tbl_employee = DB::connection("intra_payroll")->table("tbl_employee")
                ->whereBetween("date_created", [$request->from, $request->to])
                ->orderBy("last_name")
                ->orderBy("first_name")
                ->orderBy("middle_name")
                ->orderBy("ext_name")
                ->get();

        }else{
             $tbl_employee = DB::connection("intra_payroll")->table("tbl_employee")
                ->whereBetween("date_created", [$request->from, $request->to])
                 ->where("id", Auth::user()->company["linked_employee"]["id"])
                ->orderBy("last_name")
                ->orderBy("first_name")
                ->orderBy("middle_name")
                ->orderBy("ext_name")
                ->get();
        }


          
            $header = array();
            
            array_push($header, 'EMP CODE');
            array_push($header, 'BIO ID');
            array_push($header, 'FIRST NAME');
            array_push($header, 'MIDDLE NAME');
            array_push($header, 'LAST NAME');
            array_push($header, 'EXT NAME');
            array_push($header, 'CONTACT');
            array_push($header, 'POSITION');
            array_push($header, 'TYPE');
            array_push($header, 'RATE');
            array_push($header, 'IS MINIMUM WAGE EARNER');
            array_push($header, 'ADDRESS');
            array_push($header, 'department');
            array_push($header, 'branch_id');
            array_push($header, 'designation');
            array_push($header, 'DIRECT');
            array_push($header, 'AGENCY');
            array_push($header, 'SSS NO');
            array_push($header, 'PH NO');
            array_push($header, 'HDMF NO');
            array_push($header, 'TIN NO');
            array_push($header, 'Date Enrolled');

            
            $yesno = array(
                "0" => "NO",
                "1" => "YES",  
            );
            
            $excel_data = array();
            foreach($tbl_employee as $emp){
                $excel = array();
                
                $excel["emp_code"] = $emp->emp_code;
                $excel["bio_id"] = $emp->bio_id;
                $excel["first_name"] = $emp->first_name;
                $excel["middle_name"] = $emp->middle_name;
                $excel["last_name"] = $emp->last_name;
                $excel["ext_name"] = $emp->ext_name;
                $excel["contact_no"] = $emp->contact_no;

                $lib = $this->search_to_array($lib_position, "id", $emp->position_id);
                if(count($lib)==1){ $excel["position_id"] = $lib[0]["name"];}else{ $excel["position_id"] = "N/A";}

                $excel["salary_type"] = $emp->salary_type;
                $excel["salary_rate"] = $emp->salary_rate;


                $excel["is_mwe"] = $yesno[$emp->is_mwe];
                $excel["address"] = $emp->address;
                
                $lib = $this->search_to_array($tbl_department, "id", $emp->department);
                if(count($lib)==1){ $excel["department"] = $lib[0]["department"];}else{ $excel["department"] = "N/A";}
              
                $lib = $this->search_to_array($tbl_branch, "id", $emp->branch_id);
                if(count($lib)==1){ $excel["branch_id"] = $lib[0]["branch"];}else{ $excel["branch_id"] = "N/A";}
              
                $lib = $this->search_to_array($lib_designation, "id", $emp->designation);
                if(count($lib)==1){ $excel["designation"] = $lib[0]["name"];}else{ $excel["designation"] = "N/A";}



                $excel["is_direct"] = $yesno[$emp->is_direct];
                $excel["agency_name"] = $emp->agency_name;
                $excel["sss_number"] = $emp->sss_number;
                $excel["philhealth_number"] = $emp->philhealth_number;
                $excel["hdmf_number"] = $emp->hdmf_number;
                $excel["tin_number"] = $emp->tin_number;
                $excel["date_created"] = $emp->date_created;
                
                array_push($excel_data, $excel);
            }
            
            $excel_data = collect($excel_data);
            return Excel::download(new exportExcel($excel_data,$header), "Employee_list".$request->from."_".$request->to.".xlsx");


    }

    public function exportTimeKeeping(Request $request){

        if(Auth::user()->access["report_management"]["user_type"] != "employee"){
            $timecard = DB::connection("intra_payroll")->table("tbl_timekeeping")
                ->whereBetween("date_target", [$request->from, $request->to])
                ->orderBy("emp_id")
                ->get();

        }else{
             $timecard = DB::connection("intra_payroll")->table("tbl_timekeeping")
                ->whereBetween("date_target", [$request->from, $request->to])
                ->where("emp_id", Auth::user()->company["linked_employee"]["id"])
                ->orderBy("emp_id")
                ->get();
        }


            $tbl_employee = DB::connection("intra_payroll")->table("tbl_employee")->get();
            $tbl_employee = json_decode(json_encode($tbl_employee), true);
    
            $header = array();
            
            array_push($header, "Employee Code");
            array_push($header, "Last Name");
            array_push($header, "First Name");
            array_push($header, "Middle Name");
            array_push($header, "Extension Name");
            array_push($header, "Regular Work");
            array_push($header, "Lates");
            array_push($header, "Regular Overtime");
            array_push($header, "Special OverTime");
            array_push($header, "Night Differential");
            array_push($header, "Regular Leave");
            array_push($header, "Sick Leave");
            array_push($header, "Special Leave");
            array_push($header, "Regular Holiday");
            array_push($header, "Special Holiday");
            
            $excel_data = array();
            foreach($timecard as $tc){
                $excel = array();
                $emp_data = $this->search_to_array($tbl_employee, "id",$tc->emp_id);
                if(count($emp_data)==1){
                    $excel["emp_code"] = $emp_data[0]["emp_code"];
                    $excel["last_name"] = $emp_data[0]["last_name"];
                    $excel["first_name"] = $emp_data[0]["first_name"];
                    $excel["middle_name"] = $emp_data[0]["middle_name"];
                    $excel["ext_name"] = $emp_data[0]["ext_name"];
                    
                }else{
                    $excel["emp_code"] = "N/A";
                    $excel["last_name"] = "N/A";
                    $excel["first_name"] = "N/A";
                    $excel["middle_name"] = "N/A";
                    $excel["ext_name"] = "N/A";

                }

                $excel["date"] = $tc->date_target;
                $excel["regular work"] = $tc->regular_work;
                $excel["lates"] = $tc->lates;
                $excel["regular_ot"] = $tc->regular_ot;
                $excel["special_ot"] = $tc->special_ot;
                $excel["night_diff"] = $tc->night_diff;
                $excel["regular_leave"] = $tc->regular_leave;
                $excel["sick_leave"] = $tc->sick_leave;
                $excel["special_leave"] = $tc->special_leave;
                $excel["regular_holiday"] = $tc->regular_holiday;
                $excel["special_holiday"] = $tc->special_holiday;
                
                array_push($excel_data, $excel);
            }
            
            $excel_data = collect($excel_data);
            return Excel::download(new exportExcel($excel_data,$header), "TimeCard".$request->from."_".$request->to.".xlsx");


    }

    
    public function exportStatutoryReport(Request $request){
        $month_year = $request->month_year;
        $type = $request->type;
        $month = date("M", strtotime($month_year));
        $year = date("Y", strtotime($month_year));


        $tbl_employee = DB::connection("intra_payroll")->table("tbl_employee")->get();
        $tbl_employee = json_decode(json_encode($tbl_employee), true);

        $header = array();
        
        if(Auth::user()->access["report_management"]["user_type"] != "employee"){
            $payroll_list = DB::connection("intra_payroll")->table("tbl_payroll")
            ->where("target_month", "LIKE",$month)
            ->where("target_year", $year)
            ->get();
            $reg_emp_id = "all";
        }else{
             $emp_id_logged = "|".Auth::user()->company["linked_employee"]["id"]."|";
            $reg_emp_id = Auth::user()->company["linked_employee"]["id"];
            $payroll_list = DB::connection("intra_payroll")->table("tbl_payroll")
            ->where("target_month", "LIKE",$month)
            ->where("target_year", $year)
            ->where("employee", "LIKE","%".$emp_id_logged."%")
            ->get();


        }


       

            array_push($header, "Payroll Name");
            array_push($header, "Month");
            array_push($header, "Year");
            
            array_push($header, "Employee Code");
            array_push($header, "Last Name");
            array_push($header, "First Name");
            array_push($header, "Middle Name");
            array_push($header, "Extension Name");
            array_push($header, $type);

                //  dd($payroll_list);

            $excel_data = array();
            foreach($payroll_list as $payroll){
                $lib_deduction =  DB::connection("intra_payroll")->table("tbl_payroll_deduction")
                    ->where("payroll_id", $payroll->id)
                    ->where("type", $type)
                    ->get();

                    foreach($lib_deduction as $ded){
                        $excel = array();

                        if($reg_emp_id != "all"){
                            if($ded->emp_id != $reg_emp_id){continue;}
                        } 


                        $excel["payname"] = $payroll->name;
                        $excel["month"] = $payroll->target_month;
                        $excel["year"] = $payroll->target_year;

                        $emp_data = $this->search_to_array($tbl_employee, "id",$ded->emp_id);
                        if(count($emp_data)==1){
                            $excel["emp_code"] = $emp_data[0]["emp_code"];
                            $excel["last_name"] = $emp_data[0]["last_name"];
                            $excel["first_name"] = $emp_data[0]["first_name"];
                            $excel["middle_name"] = $emp_data[0]["middle_name"];
                            $excel["ext_name"] = $emp_data[0]["ext_name"];
                            
                        }else{
                            $excel["emp_code"] = "N/A";
                            $excel["last_name"] = "N/A";
                            $excel["first_name"] = "N/A";
                            $excel["middle_name"] = "N/A";
                            $excel["ext_name"] = "N/A";
    
                        }

                        $excel[$type] = $ded->amount;


                        array_push($excel_data, $excel);
                    }
                


                    



            }
            

          
            $excel_data = collect($excel_data);
            return Excel::download(new exportExcel($excel_data,$header), "Statutory_".$type."_".$month."_".$year.".xlsx");







    }





    public function exportPayrollReport(Request $request)
    {
        

        $payroll_id = $request->payid;
        $payroll = DB::connection("intra_payroll")->table("tbl_payroll")
            ->where("id", $payroll_id)
            ->first();
            
        if($payroll != null){
            $tbl_employee = DB::connection("intra_payroll")->table("tbl_employee")->get();
            $tbl_employee = json_decode(json_encode($tbl_employee), true);

            $lib_position = json_decode(json_encode(DB::connection("intra_payroll")->table("lib_position")->get()),true);
            $tbl_branch = json_decode(json_encode(DB::connection("intra_payroll")->table("tbl_branch")->get()),true);
            $tbl_department = json_decode(json_encode(DB::connection("intra_payroll")->table("tbl_department")->get()),true);
            $lib_designation = json_decode(json_encode(DB::connection("intra_payroll")->table("lib_designation")->get()),true);
            


            $income_field = array();
            $deduct_field = array();
            $header = array();
            //INCOMES
            $data_incomes = DB::connection("intra_payroll")->table("tbl_payroll_income")->where("payroll_id", $payroll->id)->get();
            $data_incomes = json_decode(json_encode($data_incomes),true);
            
            $incomes = DB::connection("intra_payroll")->table("tbl_payroll_income")
                ->select("type")
                ->where("payroll_id", $payroll->id)
                ->groupBy("type")
                ->get();
                foreach($incomes as $inc_type){
                    $income_field[$inc_type->type] = $inc_type->type;
                }
                
            $income_header = array(
                "BP" => "Basic Pay",
                "RH" => "Regular Holiday",
                "ROT" => "Regular Overtime",
                "SOT" => "Special Overtime",
                "13TH" => "13th Month Pay",
                "SH" => "Special Holiday",
                "ND" => "Night Differential",
            );

            $lib_income  = DB::connection("intra_payroll")->table("lib_income")->get();
            $lib_income = json_decode(json_encode($lib_income),true);
           
       

                array_push($header, "Employee Code");
                array_push($header, "Last Name");
                array_push($header, "First Name");
                array_push($header, "Middle Name");
                array_push($header, "Extension Name");
                
                array_push($header, "Designation");
                array_push($header, "Position");
                array_push($header, "Department");
                array_push($header, "Branch");
                
                
                //ARRAY HEADER
                foreach($income_field as $column){
                    $column_id = str_replace("R_","",$column);
                    $col_name = $this->search_to_array($lib_income,"id", $column_id);
                        if(count($col_name)>0){
                           $column = $col_name[0]["name"];
                        }else{
                           $column = $income_header[$column];
                        }    

                    array_push($header, $column);
                }

                array_push($header, "Total Gross Pay");
                
        // DEDUCTION
            $data_deductions = DB::connection("intra_payroll")->table("tbl_payroll_deduction")->where("payroll_id", $payroll->id)->get();
            $data_deductions = json_decode(json_encode($data_deductions),true);
            
            $deductions = DB::connection("intra_payroll")->table("tbl_payroll_deduction")
                ->select("type")
                ->where("payroll_id", $payroll->id)
                ->groupBy("type")
                ->get();
                foreach($deductions as $ded_type){
                    $deduct_field[$ded_type->type] = $ded_type->type;
                }
                
                

            $deduction_header = array(
                "SSS" => "SSS",
                "HDMF" => "PAGIBIG I (HDMF)",
                "PH" => "PhilHealth",
                "TAX" => "WIHHOLDING TAX",
                "LATE" => "LATE",
                "ABSENT" => "ABSENT",
            );

            $lib_loans  = DB::connection("intra_payroll")->table("lib_loans")->get();
            $lib_loans = json_decode(json_encode($lib_loans),true);
           
       
                //ARRAY HEADER
                foreach($deduct_field as $ded_col){
                    $ded_col_id = str_replace("R_","",$ded_col);
                    $ded_col_name = $this->search_to_array($lib_loans,"id", $ded_col_id);
                        if(count($ded_col_name)>0){
                           $column = $ded_col_name[0]["name"];
                        }else{
                           $column = $deduction_header[$ded_col];
                        }    

                    array_push($header, $column);
                }

                array_push($header, "Total Deduction");

            array_push($header, "Net Pay");   


            $excel_data = array();    
            $employee = explode(";",$payroll->employee);
                foreach($employee as $emp){
                    $excel = array();
                    $emp_id = str_replace("|", "", $emp);

                    $emp_data = $this->search_to_array($tbl_employee, "id",$emp_id);

                        if(count($emp_data)==1){
                            
                            $excel["emp_code"] = $emp_data[0]["emp_code"];
                            $excel["last_name"] = $emp_data[0]["last_name"];
                            $excel["first_name"] = $emp_data[0]["first_name"];
                            $excel["middle_name"] = $emp_data[0]["middle_name"];
                            $excel["ext_name"] = $emp_data[0]["ext_name"];

                            
                            $lib = $this->search_to_array($lib_designation, "id", $emp_data[0]["designation"]);
                            if(count($lib)==1){ $excel["designation"] = $lib[0]["name"];}else{ $excel["designation"] = "N/A";}

                            $lib = $this->search_to_array($lib_position, "id", $emp_data[0]["position_id"]);
                            if(count($lib)==1){ $excel["position"] = $lib[0]["name"];}else{ $excel["position"] = "N/A";}

                            $lib = $this->search_to_array($tbl_department, "id", $emp_data[0]["department"]);
                            if(count($lib)==1){ $excel["department"] = $lib[0]["department"];}else{ $excel["department"] = "N/A";}

                            $lib = $this->search_to_array($tbl_branch, "id", $emp_data[0]["branch_id"]);
                            if(count($lib)==1){ $excel["branch"] = $lib[0]["branch"];}else{ $excel["branch"] = "N/A";}                          
                          
                          

                        }else{
                            $excel["emp_code"] = "N/A";
                            $excel["last_name"] = "N/A";
                            $excel["first_name"] = "N/A";
                            $excel["middle_name"] = "N/A";
                            $excel["ext_name"] = "N/A";
                            
                            $excel["designation"] = "N/A";
                            $excel["position"] = "N/A";
                            $excel["department"] = "N/A";
                            $excel["branch"] = "N/A";
                        }

                   

                    $total_income = 0;
                    $total_deduction = 0;
                    //INCOME
                    $inc_data = $this->search_to_array($data_incomes, "emp_id",$emp_id);
                    foreach($income_field as $key => $dat){
                            $inc_amount = $this->search_to_array($inc_data,"type", $dat);
                            if(count($inc_amount) > 0){
                                $total_income += $inc_amount[0]["amount"];
                                $excel[$dat] = $inc_amount[0]["amount"];
                            }else{
                                $excel[$dat] = 0;
                            }
                           
                    }
                    $excel['total_gross'] = $total_income;

                    //DEDUCTION
                    $ded_data = $this->search_to_array($data_deductions, "emp_id",$emp_id);
                    foreach($deduct_field as $key => $dat_ded){
                            $ded_amount = $this->search_to_array($ded_data,"type", $dat_ded);
                            if(count($ded_amount) > 0){
                                $total_deduction += $ded_amount[0]["amount"];
                                $excel[$dat_ded] = $ded_amount[0]["amount"];
                            }else{
                                $excel[$dat_ded] = 0;
                            }
                           
                    }
                    $excel['total_deductions'] = $total_deduction;

                    $excel['net_pay'] = $total_income - $total_deduction;

                    array_push($excel_data, $excel);
                }

                $excel_data = collect($excel_data);
                return Excel::download(new exportExcel($excel_data,$header), $payroll->name.".xlsx");
        }

        
    }

}
